return {
	SYSCONFDIR = [[C:\Games\1337SAMP\moonloader\luarocks]],
	SYSTEM = [[windows]],
	FORCE_CONFIG = true,
	LUA_INCDIR = [[C:\Games\1337SAMP\moonloader\luajit\inc]],
	LUA_LIBDIR = [[C:\Games\1337SAMP\moonloader\luajit\lib]],
	LUA_DIR = [[C:\Games\1337SAMP\moonloader\luajit]],
	LUA_INTERPRETER = [[luajit.exe]],
	WIN_TOOLS = [[C:\Games\1337SAMP\moonloader\luarocks\tools]],
	LUA_BINDIR = [[C:\Games\1337SAMP\moonloader\luajit\bin]],
	PROCESSOR = [[x86]],
	PREFIX = [[C:\Games\1337SAMP\moonloader\luarocks]],
}
