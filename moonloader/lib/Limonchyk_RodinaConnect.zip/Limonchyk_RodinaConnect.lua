require 'lib.moonloader'
require 'lib.sampfuncs'
local ev = require 'lib.samp.events'
local copas = require 'copas'
local http = require 'copas.http'

script_name("Limonchyk_RodinaConnect")
script_dependencies("SAMP", "SAMPFUNCS")
script_version_number(1)
script_moonloader(025)
script_author("Andrey Sotov, VK: vk.com/idandrey.sotov")

local count = 1
local loc_id = launcherid

function main()
	if not isSampfuncsLoaded() or not isSampLoaded() then return end
	while not isSampAvailable() do wait(100) end
	
	local ip, port = sampGetCurrentServerAddress()
	
	function ev.onSendClientJoin(Ver, mod, nick, response, authKey, clientver, unk)
		clientver = 'Rodina PC'
		return {Ver, mod, nick, response, authKey, clientver, unk}
	end
	
	function httpRequest(request, body, handler) -- copas.http
		-- start polling task
		if not copas.running then
			copas.running = true
			lua_thread.create(function()
				wait(0)
				while not copas.finished() do
					local ok, err = copas.step(0)
					if ok == nil then error(err) end
					wait(0)
				end
				copas.running = false
			end)
		end
		-- do request
		if handler then
			return copas.addthread(function(r, b, h)
				copas.setErrorHandler(function(err) h(nil, err) end)
				h(http.request(r, b))
			end, request, body, handler)
		else
			local results
			local thread = copas.addthread(function(r, b)
				copas.setErrorHandler(function(err) results = {nil, err} end)
				results = table.pack(http.request(r, b))
			end, request, body)
			while coroutine.status(thread) ~= 'dead' do wait(0) end
			return table.unpack(results)
		end
	end
	sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Loaded {FFFFFF}By Andrey Sotov, VK: vk.com/idandrey.sotov - "..ip..":"..port..", Client: Rodina.")
		
	if loc_id < 1 then
	else
		if ip == "185.169.134.163" then
			if port == 7777 then
				local ip_one, code, handler, status
				httpRequest("http://213.159.208.217/launcher/server_info.php?locid="..loc_id.."&serverid=1&type=1&game=rodina", nil, function(ip_one, code, handler, status)
					if ip_one then
						httpRequest("http://213.159.208.217/launcher/server_info.php?locid="..loc_id.."&serverid=1&type=2&game=rodina", nil, function(port_one, code, handler, status)
							if port_one then
								return sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Recconnect {FFFFFF}To "..ip_one..":"..port_one.."."), sampConnectToServer(ip_one, port_one)
							end
						end)
					else
						return sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Recconnect {FFFFFF}To 185.169.134.163:7777.")
					end
				end)
			end
		end
		
		
		if ip == "185.169.134.60" then
			if port == 8904 then
				local ip_two, code, handler, status
				httpRequest("http://213.159.208.217/launcher/server_info.php?locid="..loc_id.."&serverid=2&type=1&game=rodina", nil, function(ip_two, code, handler, status)
					if ip_two then
						httpRequest("http://213.159.208.217/launcher/server_info.php?locid="..loc_id.."&serverid=2&type=2&game=rodina", nil, function(port_two, code, handler, status)
							if port_two then
								return sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Recconnect {FFFFFF}To "..ip_two..":"..port_two.."."), sampConnectToServer(ip_two, port_two)
							end
						end)
					else
						return sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Recconnect {FFFFFF}To 185.169.134.60:8904.")
					end
				end)
			end
		end

		
		if ip == "185.169.134.62" then
			if port == 8904 then
				local ip_th, code, handler, status
				httpRequest("http://213.159.208.217/launcher/server_info.php?locid="..loc_id.."&serverid=3&type=1&game=rodina", nil, function(ip_th, code, handler, status)
					if ip_th then
						httpRequest("http://213.159.208.217/launcher/server_info.php?locid="..loc_id.."&serverid=3&type=2&game=rodina", nil, function(port_th, code, handler, status)
							if port_th then
								return sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Recconnect {FFFFFF}To "..ip_th..":"..port_th.."."), sampConnectToServer(ip_th, port_th)
							end
						end)
					else
						return sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Recconnect {FFFFFF}To 185.169.134.62:8904.")
					end
				end)
			end
		end
		
		
		if ip == "185.169.134.108" then
			if port == 7777 then
				local ip_fo, code, handler, status
				httpRequest("http://213.159.208.217/launcher/server_info.php?locid="..loc_id.."&serverid=4&type=1&game=rodina", nil, function(ip_fo, code, handler, status)
					if ip_fo then
						httpRequest("http://213.159.208.217/launcher/server_info.php?locid="..loc_id.."&serverid=4&type=2&game=rodina", nil, function(port_fo, code, handler, status)
							if port_fo then
								return sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Recconnect {FFFFFF}To "..ip_fo..":"..port_fo.."."), sampConnectToServer(ip_fo, port_fo)
							end
						end)
					else
						return sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Recconnect {FFFFFF}To 185.169.134.108:7777.")
					end
				end)
			end
		end
		
		
		if ip == "80.66.71.85" then
			if port == 7777 then
				local ip_fi, code, handler, status
				httpRequest("http://213.159.208.217/launcher/server_info.php?locid="..loc_id.."&serverid=5&type=1&game=rodina", nil, function(ip_fi, code, handler, status)
					if ip_fi then
						httpRequest("http://213.159.208.217/launcher/server_info.php?locid="..loc_id.."&serverid=5&type=2&game=rodina", nil, function(port_fi, code, handler, status)
							if port_fi then
								return sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Recconnect {FFFFFF}To "..ip_fi..":"..port_fi.."."), sampConnectToServer(ip_fi, port_fi)
							end
						end)
					else
						return sampAddChatMessage("{FFB233}[Limonchyk_RodinaConnect] Recconnect {FFFFFF}To 80.66.71.85:7777.")
					end
				end)
			end
		end
	end
end
